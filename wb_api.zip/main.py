import logging
import time
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from wb_api import get_order_by_id, get_order_status, get_feedbacks, find_review_for_sku
from datetime import timezone, datetime, timedelta
from wb_api import get_order_with_full_product_info

# Конфигурация
API_TOKEN = '7284002456:AAHfv322qYyVu84Z-vGU0QCHaa37fCEwqYo'
WB_API_KEY = 'ВАШ_API_КЛЮЧ_WILDBERRIES'
ADMIN_ID = 841790448  # ID администратора

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

logging.basicConfig(level=logging.INFO)

main_inline_keyboard = InlineKeyboardMarkup(row_width=1)
main_inline_keyboard.add(
    InlineKeyboardButton("🎁 Получить кешбек за отзыв", callback_data="get_cashback")
)
main_inline_keyboard.add(
    InlineKeyboardButton("💬 Разобраться с вашей ситуацией", callback_data="solve_problem")
)

def get_cashback_status_keyboard(application_id):
    return InlineKeyboardMarkup().add(
        InlineKeyboardButton("✅ Выплатить кешбэк", callback_data=f"setcashback:реализовано:{application_id}"),
        InlineKeyboardButton("❌ Отклонить", callback_data=f"setcashback:не_реализовано:{application_id}")
    )

def generate_application_id():
    return str(int(time.time()))


def find_user_by_application_id(application_id):
    for user_id, data in user_data.items():
        if data.get('application_id') == application_id:
            return user_id, data
    return None, None

def get_status_keyboard(application_id):
    return InlineKeyboardMarkup(row_width=1).add(
        InlineKeyboardButton("✅ Удовлетворить заявку", callback_data=f"set_status=закрыто_app={application_id}"),
        InlineKeyboardButton("❌ Отклонить", callback_data=f"set_status=не реализовано_app={application_id}")
    )


def generate_admin_application_text(data):
    product = data['product']
    description = data.get('description', 'Описание отсутствует')
    return (
        f"⚠️ Обращение №{data['application_id']}\n"
        f"📦 Номер заказа: {data['order_id']}\n"
        f"📛 Проблема: {data['problem_type']}\n"
        f"📝 Описание: {description}\n"
        f"📅 Дата создания: {data['created_at']}\n"
        f"🔖 Статус: *{data['status']}*\n\n"
        f"🏷️ Товар: {product['name']}\n"
        f"🏷️ Бренд: {product['brand']}\n"
        f"💰 Цена: {product['price']} р\n"
        f"🔗 [Ссылка на товар]({product['link']})\n"
        f"📲 [Связаться с клиентом](tg://user?id={data['user_id']})\n"
    )


bank_keyboard = InlineKeyboardMarkup(row_width=2).add(
    InlineKeyboardButton("🟢 Сбербанк", callback_data="bank_sber"),
    InlineKeyboardButton("🟡 Т-Банк", callback_data="bank_tinkoff"),
    InlineKeyboardButton("🔵 ВТБ", callback_data="bank_vtb"),
    InlineKeyboardButton("🔴 Альфа-Банк", callback_data="bank_alfa"),
    InlineKeyboardButton("⚪️ Другой", callback_data="bank_other")
)

back_keyboard = InlineKeyboardMarkup(row_width=1)
back_keyboard.add(
    InlineKeyboardButton("🔙 Назад", callback_data="back")
)

back_to_main_keyboard = InlineKeyboardMarkup(row_width=1)
back_to_main_keyboard.add(
    InlineKeyboardButton("🏠 Главное меню", callback_data="back_to_main")
)


complaint_types = ["📦 Упаковка", "🛠️ Качество товара", "🚚 Доставка", "❓ Другое"]

user_data = {}

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    user_name = message.from_user.first_name

    await message.reply(
        f"Здравствуйте, {user_name}! 👋\n\n"
        "Я ваш виртуальный помощник, который поможет вам получить кэшбэк за отзыв или решить проблемы с заказом. Выберите действие:",
        reply_markup=main_inline_keyboard
    )

@dp.callback_query_handler(lambda c: c.data in ["get_cashback", "solve_problem"])
async def handle_menu(callback: types.CallbackQuery):
    if callback.data == "get_cashback":
        user_data[callback.from_user.id] = {'step': 'enter_order'}
        await callback.message.edit_text(
            "Чтобы получить кешбек, введите номер вашего заказа с упаковки! 👇",
            reply_markup=back_keyboard
        )
    elif callback.data == "solve_problem":
        user_data[callback.from_user.id] = {'step': 'problem_order'}
        await callback.message.edit_text(
            "✍️ Введите номер вашего заказа, который указан на упаковке товара. Это поможет нам разобраться с вашей проблемой. 📦",
            reply_markup=back_keyboard
        )
    await callback.answer()

@dp.callback_query_handler(lambda c: c.data == "back_to_main")
async def handle_back_to_main(callback: types.CallbackQuery):
    await callback.message.edit_text(
        "Я ваш виртуальный помощник, который поможет вам получить кэшбэк за отзыв или решить проблемы с заказом. Выберите действие:",
        reply_markup=main_inline_keyboard
    )
    user_data.pop(callback.from_user.id, None)  # Сброс текущего сценария, если был
    await callback.answer()


@dp.message_handler(lambda m: user_data.get(m.from_user.id, {}).get('step') == 'enter_order')
async def process_order_for_cashback(message: types.Message):
    order_id = message.text.strip()

    order, error = get_order_by_id(WB_API_KEY, order_id)
    if error:
        await message.reply(
            f"❗ Заказ не найден.\nУважаемый пользователь, к сожалению, мы не смогли найти заказ по указанным данным." +
            "\n\nПроверьте правильность информации и попробуйте еще раз.\nЕсли проблема сохраняется, свяжитесь с нашей поддержкой для помощи:",
            reply_markup=InlineKeyboardMarkup(row_width=1).add(
                InlineKeyboardButton("🔄 Повторить ввод", callback_data="retry_order_input_cash"),
                InlineKeyboardButton("✉️ Написать в поддержку", url=f"tg://user?id={ADMIN_ID}"),
                InlineKeyboardButton("🏠 Главное меню", callback_data="back_to_main")
            )
        )
        return

    status, error = get_order_status(WB_API_KEY, order_id)
    if error:
        await message.reply(f"❌ Ошибка получения статуса: {error}")
        return

    if status['wbStatus'] != 'sold':
        await message.reply("⚠️ Этот заказ еще не завершен (не получен клиентом). Кешбэк пока невозможен.")
        return

    if error:
        await message.reply(f"❌ Ошибка получения товара: {error}")
        return

    feedbacks, error = get_feedbacks(order['nmId'])
    if error:
        await message.reply(f"❌ Ошибка получения отзывов: {error}")
        return

    review = find_review_for_sku(feedbacks, order['skus'])
    if not review:
        await message.reply(
            "❗️ Отзыв не найден.\nПожалуйста, оставьте отзыв на Wildberries, а затем вернитесь сюда.\n\n"
            "Вот как правильно оставить отзыв:\n\n"
            "1️⃣ Достоинства\nПоделитесь тем, что вам понравилось в товаре! Это может быть качество, функциональность или что-то другое. Ваша положительная оценка поможет нам улучшать сервис! 🌟\n\n"
            "2️⃣ Недостатки\nУкажите, что можно улучшить: размер, управление, упаковка и т.д. Ваше мнение важно для нас! 👍\n\n"
            "3️⃣ Комментарий\nРасскажите о своём опыте использования: почему выбрали этот товар, оправдал ли он ожидания, кому бы порекомендовали. Это поможет другим покупателям сделать лучший выбор! 💬\n\n"
            "📚 Пример отзыва:\nДостоинства: Приятный материал, удобные режимы.\nНедостатки: Немного сложно привыкнуть к управлению.\nКомментарий: Отличная покупка, рекомендую!\n\n"
            "✍️ Оставьте отзыв и нажмите \"Готово\", чтобы получить кешбек!\n\n",
            reply_markup=InlineKeyboardMarkup().add(
                InlineKeyboardButton("Оставить отзыв",
                                     url=f"https://www.wildberries.ru/catalog/{order['nmId']}/detail.aspx#comments")
            ).add(
                InlineKeyboardButton("🏠 Главное меню", callback_data="back_to_main")
            )
        )
        return

    # Теперь review точно есть
    product = {
        'name': review['productDetails']['productName'],
        'brand': review['productDetails']['brandName'],
        'link': f"https://www.wildberries.ru/catalog/{order['nmId']}/detail.aspx"
    }

    user_data[message.from_user.id] = {
        'step': 'phone_number',
        'order_id': order_id,
        'order': order,
        'order_date': order['createdAt'],
        'product': product,
        'review': review
    }

    await message.reply(
        "✅ Ваш отзыв подтвержден!\n\n"
        "Для продолжения оформления заявки на выплату кэшбека нажмите кнопку ниже",
        reply_markup=InlineKeyboardMarkup().add(
            InlineKeyboardButton("💸 Оставить заявку на кешбек", callback_data="start_cashback_request")
        )
    )

@dp.callback_query_handler(lambda c: c.data == "start_cashback_request")
async def handle_cashback_request_start(callback: types.CallbackQuery):

    user_data[callback.from_user.id]['step'] = 'phone_number'

    await callback.message.edit_text("📱 Для начисления кешбека нам нужен ваш номер телефона.\nПожалуйста, поделитесь номером или введите его вручную - выберите, как вам удобнее! 👇")
    await callback.answer()


@dp.message_handler(lambda m: user_data.get(m.from_user.id, {}).get('step') == 'phone_number')
async def process_phone_number(message: types.Message):
    user_data[message.from_user.id]['phone'] = message.text.strip()
    user_data[message.from_user.id]['step'] = 'choose_bank'
    await message.reply("🏦 Выберите ваш банк:", reply_markup=bank_keyboard)

@dp.callback_query_handler(lambda c: c.data.startswith("bank_"))
async def process_bank_choice(callback: types.CallbackQuery):
    if callback.from_user.id not in user_data:
        await callback.message.answer("❗️ Ошибка: ваши данные не найдены, сценарий сброшен. Начните заново.")
        await send_welcome(callback.message)
        return

    bank = callback.data.replace("bank_", "")
    bank_names = {
        "sber": "Сбербанк",
        "tinkoff": "Т-Банк",
        "vtb": "ВТБ",
        "alfa": "Альфа-Банк",
        "other": "Другой"
    }
    user_data[callback.from_user.id]['bank'] = bank_names[bank]

    await send_cashback_to_admin(callback.from_user.id)
    await callback.message.answer("✅ Заявка отправлена администратору! Ожидайте обратной связи.")
    await callback.answer()


async def send_cashback_to_admin(user_id):
    data = user_data[user_id]

    application_id = generate_application_id()
    data.update({
        "application_id": application_id,
        "application_type": "cashback",
        "status": "в работе",
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "user_id": user_id
    })

    product = data['product']
    review = data['review']
    order = data['order']

    sale_date = datetime.fromisoformat(order['createdAt']).replace(tzinfo=timezone.utc)
    days_passed = (datetime.now(timezone.utc) - sale_date).days
    can_pay = "ДА" if days_passed >= 14 else "НЕТ"

    text = (
        f"📋 Заявка на кешбэк №{application_id}\n"
        f"📦 Номер заказа: {order['id']}\n"
        f"🏷️ Товар: {product['name']} ({product['brand']})\n"
        f"⭐️ Оценка клиента: {review['productValuation']}⭐️\n"
        f"🗓️ Дата отзыва: {review['createdDate']}\n"
        f"🛒 Дата продажи: {sale_date.date()}\n"
        f"📅 Дней с момента продажи: {days_passed}\n"
        f"💬 Отзыв: {review.get('text', 'Отзыв без текста')}\n"
        f"📱 Телефон: {data['phone']}\n"
        f"🏦 Банк: {data['bank']}\n"
        f"💸 Начислить кешбэк: {can_pay}\n"
        f"📲 [Связаться с клиентом](tg://user?id={user_id})"
    )

    message = await bot.send_message(ADMIN_ID, text, parse_mode="Markdown")
    data['admin_message_id'] = message.message_id

    user_data[user_id] = data  # Обязательно обновляем

    await bot.send_message(ADMIN_ID, "Выберите решение по кешбэку:", reply_markup=get_cashback_status_keyboard(application_id))



@dp.callback_query_handler(lambda c: c.data.startswith("setcashback:"))
async def change_cashback_status(callback: types.CallbackQuery):
    _, status, application_id = callback.data.split(":")
    user_id, data = find_user_by_application_id(application_id)

    if not data:
        await callback.answer("Заявка не найдена.")
        return

    data['status'] = status
    text = f"📋 Заявка на кешбэк (обновлено)\n\n{data['product']['name']}\n🔖 Статус: *{status}*"
    await bot.edit_message_text(text, ADMIN_ID, data['admin_message_id'], parse_mode="Markdown")

    messages = {
        "реализовано": "✅ Ваш кешбэк выплачен!",
        "не_реализовано": "❌ В кешбэке отказано. Свяжитесь с поддержкой, если есть вопросы."
    }
    await bot.send_message(user_id, f"ℹ️ Статус заявки на кешбэк: {messages[status]}")
    await callback.answer()


@dp.message_handler(lambda m: user_data.get(m.from_user.id, {}).get('step') == 'problem_order')
async def process_order_for_problem(message: types.Message):
    order_id = message.text.strip()

    order, error = get_order_with_full_product_info(WB_API_KEY, order_id)
    if error:
        await message.reply(
            "❗ Заказ не найден. Проверьте номер и попробуйте снова.",
            reply_markup=InlineKeyboardMarkup(row_width=1).add(
                InlineKeyboardButton("🔄 Повторить ввод", callback_data="retry_order_input_problem"),
                InlineKeyboardButton("✉️ Написать в поддержку", url=f"tg://user?id={ADMIN_ID}"),
                InlineKeyboardButton("🏠 Главное меню", callback_data="back_to_main")
            )
        )
        return

    sale_date = datetime.fromisoformat(order['createdAt']).replace(tzinfo=timezone.utc)
    days_since_sale = (datetime.now(timezone.utc) - sale_date).days

    product = order['product_info']

    user_data[message.from_user.id] = {
        'step': 'choose_problem',
        'order_id': order_id,
        'product': product,
        'days_since_sale': days_since_sale  # вот это теперь сохраняется
    }

    text = (
        f"📋 Информация о покупке\n"
        f"├📦 Товар: {product['name']}\n"
        f"├📂 Категория: {product['category']}\n"
        f"└🏷️ Бренд: {product['brand']}\n\n"
        f"💰 Стоимость:\n"
        f"├🏷️ Изначальная цена: {product['old_price']} р\n"
        f"├💥 Скидка: {product['discount']}%\n"
        f"└💰 Итоговая цена со скидкой: {product['price']} р\n\n"
        f"🔗 [Ссылка на товар]({product['link']})"
    )

    await message.reply(
        f"{text}\n\nВсе верно? Если да — нажмите «Продолжить».",
        reply_markup=InlineKeyboardMarkup(row_width=1).add(
            InlineKeyboardButton("✅ Продолжить", callback_data="confirm_product")
        )
    )



@dp.callback_query_handler(lambda c: c.data == "confirm_product")
async def confirm_product(callback: types.CallbackQuery):
    user_data[callback.from_user.id]['step'] = 'choose_problem'

    await callback.message.edit_text(
        "📋 Выберите, с чем у вас возникла проблема:",
        reply_markup=InlineKeyboardMarkup().add(
            *[InlineKeyboardButton(pt, callback_data=f"problem_{pt}") for pt in complaint_types]
        )
    )
    await callback.answer()


@dp.callback_query_handler(lambda c: c.data == "retry_order_input_problem")
async def retry_order_input(callback: types.CallbackQuery):
    user_data[callback.from_user.id] = {'step': 'problem_order'}
    await callback.message.edit_text(
        "✍️ Введите номер вашего заказа, который указан на упаковке товара. Это поможет нам разобраться с вашей проблемой. 📦",
        reply_markup=back_to_main_keyboard
    )
    await callback.answer()

@dp.callback_query_handler(lambda c: c.data == "retry_order_input_cash")
async def retry_order_input(callback: types.CallbackQuery):
    user_data[callback.from_user.id] = {'step': 'problem_order'}
    await callback.message.edit_text(
        "Чтобы получить кешбек, введите номер вашего заказа с упаковки! 👇",
        reply_markup=back_to_main_keyboard
    )
    await callback.answer()

@dp.callback_query_handler(lambda c: c.data.startswith("problem_"))
async def process_problem_type(callback: types.CallbackQuery):
    user_data[callback.from_user.id]['problem_type'] = callback.data.replace("problem_", "")
    user_data[callback.from_user.id]['step'] = 'enter_name'
    await callback.message.answer("📛 Пожалуйста, введите ваше ФИО:")
    await callback.answer()

@dp.message_handler(lambda m: user_data.get(m.from_user.id, {}).get('step') == 'enter_name')
async def collect_name(message: types.Message):
    user_data[message.from_user.id]['name'] = message.text.strip()
    user_data[message.from_user.id]['step'] = 'enter_phone'
    await message.reply("📱 Теперь укажите ваш номер телефона для обратной связи:")

@dp.message_handler(lambda m: user_data.get(m.from_user.id, {}).get('step') == 'enter_phone')
async def collect_phone(message: types.Message):
    user_data[message.from_user.id]['phone'] = message.text.strip()
    user_data[message.from_user.id]['step'] = 'problem_description'
    await message.reply("📝 Опишите проблему. Вы также можете прикрепить до 5 фотографий:")

@dp.message_handler(lambda m: user_data.get(m.from_user.id, {}).get('step') == 'problem_description', content_types=types.ContentType.ANY)
async def collect_problem_data(message: types.Message):
    user_id = message.from_user.id

    # Создаем структуру, если её нет (или чего-то не хватает)
    if user_id not in user_data:
        user_data[user_id] = {}

    data = user_data[user_id]

    # Обязательно гарантируем, что description и photos есть
    if 'description' not in data:
        data['description'] = ''
    if 'photos' not in data:
        data['photos'] = []

    # Заполняем описание и фото
    if message.text:
        data['description'] += message.text.strip() + '\n'

    if message.photo:
        if len(data['photos']) < 5:
            data['photos'].append(message.photo[-1].file_id)
            if message.caption:
                data['description'] += message.caption.strip() + '\n'

    user_data[user_id] = data  # обновили данные

    await message.reply(
        "✅ Данные добавлены. Можете отправить ещё или нажмите «Завершить заявку».",
        reply_markup=InlineKeyboardMarkup().add(
            InlineKeyboardButton("✅ Завершить заявку", callback_data="finish_problem_report")
        )
    )

@dp.callback_query_handler(lambda c: c.data == "finish_problem_report")
async def finalize_problem_report(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    data = user_data.get(user_id)

    if not data:
        await callback.answer("Ошибка: заявка не найдена.")
        return

    application_id = generate_application_id()
    data.update({
        'application_id': application_id,
        'status': 'в работе',
        'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'user_id': user_id
    })

    await callback.message.answer(
        f"✅ Заявка принята!\n"
        f"📄 Номер обращения: {application_id}\n"
        f"⏳ Ожидаемое время ответа: в течение 24 часов"
    )

    await send_problem_report_to_admin(user_id)
    await callback.answer()


async def send_problem_report_to_admin(user_id):
    data = user_data.get(user_id)
    product = data['product']

    main_text = (
        f"⚠️ Новая заявка\n"
        f"📄 Номер обращения: {data['application_id']}\n"
        f"📦 Номер заказа: {data['order_id']}\n"
        f"📛 Проблема: {data['problem_type']}\n"
        f"📝 Описание: {data['description'].strip() or 'Описание не указано'}\n"
        f"📅 Дата создания: {data['created_at']}\n"
        f"⏳ Дней с момента продажи: {data.get('days_since_sale', 'неизвестно')}\n\n"
        f"👤 ФИО: {data['name']}\n"
        f"📱 Телефон: {data['phone']}\n"
        f"🏷️ Товар: {product['name']}\n"
        f"🏷️ Бренд: {product['brand']}\n"
        f"💰 Цена: {product['price']} р\n"
        f"🔗 [Ссылка на товар]({product['link']})\n"
        f"📲 [Связаться с клиентом](tg://user?id={user_id})"
    )

    sent_message = await bot.send_message(ADMIN_ID, main_text, parse_mode="Markdown", disable_web_page_preview=True)

    if data.get('photos'):
        media_group = [types.InputMediaPhoto(photo) for photo in data['photos']]
        await bot.send_media_group(ADMIN_ID, media_group)

    data['admin_message_id'] = sent_message.message_id
    user_data[user_id] = data

    status_keyboard = InlineKeyboardMarkup().add(
        InlineKeyboardButton("✅ Закрыть с решением", callback_data=f"setstatus:закрыто:{data['application_id']}"),
        InlineKeyboardButton("❌ Отклонить (не решено)", callback_data=f"setstatus:не_реализовано:{data['application_id']}")
    )

    await bot.send_message(ADMIN_ID, "Выберите статус обращения:", reply_markup=status_keyboard)

@dp.callback_query_handler(lambda c: c.data.startswith("setstatus:"))
async def change_application_status(callback: types.CallbackQuery):
    _, status, application_id = callback.data.split(":")
    user_id, data = find_user_by_application_id(application_id)

    if not data:
        await callback.answer("Заявка не найдена.")
        return

    data['status'] = status
    user_data[user_id] = data

    new_text = (
        f"⚠️ Обращение №{data['application_id']}\n"
        f"📦 Номер заказа: {data['order_id']}\n"
        f"📛 Проблема: {data['problem_type']}\n"
        f"📝 Описание: {data['description'].strip() or 'Описание не указано'}\n"
        f"📅 Дата создания: {data['created_at']}\n\n"
        f"🏷️ Товар: {data['product']['name']}\n"
        f"🏷️ Бренд: {data['product']['brand']}\n"
        f"💰 Цена: {data['product']['price']} р\n"
        f"🔗 [Ссылка на товар]({data['product']['link']})\n"
        f"📲 [Связаться с клиентом](tg://user?id={user_id})\n"
        f"🔖 Статус: *{status}*"
    )

    await bot.edit_message_text(new_text, ADMIN_ID, data['admin_message_id'], parse_mode="Markdown", disable_web_page_preview=True)

    status_messages = {
        "закрыто": "✅ Ваша заявка закрыта и решена.",
        "не_реализовано": "❌ Ваша заявка закрыта без решения."
    }
    await bot.send_message(user_id, f"ℹ️ Статус вашей заявки №{application_id} изменен:\n{status_messages[status]}")
    await callback.answer("Статус обновлён.")


executor.start_polling(dp)